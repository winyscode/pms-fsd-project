import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { RegisterComponent } from './components/register/register.component';
import { AboutusComponent } from './components/aboutus/aboutus.component';

import { AdminAuthGuard, UserAuthGuard } from './guards/index';
import { AuthenticationService, UserService, PolicyService } from './services/index';
import { PolicyComponent } from './policy/policy.component';

const appRoutes: Routes = [ 
  {
    path: 'dashboard',
    component: DashboardComponent,
    canActivate: [UserAuthGuard]
  },

  {
    path: 'register',
    component: RegisterComponent
  },

  {
    path: 'policy/:id',
    component: PolicyComponent,
    canActivate: [AdminAuthGuard]
  },

  {
    path: 'about-us',
    component: AboutusComponent
  },

  {
    path: '**',
    component: LoginComponent
  }
];


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    RegisterComponent,
    AboutusComponent,
    PolicyComponent
  ],
  imports: [
     RouterModule.forRoot(
      appRoutes,
      //{ enableTracing: true } // <-- debugging purposes only
    ),
    BrowserModule,
    HttpClientModule,
    FormsModule,
	ReactiveFormsModule
  ],
  providers: [
    AdminAuthGuard,
    UserAuthGuard,
    AuthenticationService,
    UserService,
    PolicyService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
