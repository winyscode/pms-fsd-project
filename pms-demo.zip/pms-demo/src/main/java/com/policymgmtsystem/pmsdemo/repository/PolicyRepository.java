package com.policymgmtsystem.pmsdemo.repository;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.policymgmtsystem.pmsdemo.model.PolicyMaster;

@Repository
public interface PolicyRepository extends JpaRepository<PolicyMaster, Long>{

	PolicyMaster findByPolicyID(String policyID);

}
