package com.policymgmtsystem.pmsdemo.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.policymgmtsystem.pmsdemo.model.PolicyDetail;
import com.policymgmtsystem.pmsdemo.model.UserDetail;
import com.policymgmtsystem.pmsdemo.repository.PolicyRepository;
import com.policymgmtsystem.pmsdemo.repository.UserRepository;

@RestController
@RequestMapping("/api")
public class PolicyController {

	@Autowired
	PolicyRepository policyRepo;
	
	@Autowired
	UserRepository userRepo;
	
	//GET http://localhost:8004/api/policies
	// Get all policies for Admin
	@GetMapping("/policies")
	public List<PolicyDetail> getAllPolicies() {
		return policyRepo.findAll();

	}
	
	//GET http://localhost:8004/api/policies/7000001
	// Get a Single Policy for Admin to view and edit
	@GetMapping("/policies/{id}")
	public PolicyDetail getPolicyById(@PathVariable(value = "id") String policyID) {
	    return policyRepo.findByPolicyID(policyID);
	    		 // .orElseThrow(() -> new ResourceNotFoundException("PolicyMaster", "id", policyID));
	}
	
	//PUT http://localhost:8004/api/policies/7000001
	// Update a Policy
	@PutMapping("/policies/{id}")
	public PolicyDetail updatePolicy(@PathVariable(value = "id") String policyID,
	                                        @Valid @RequestBody PolicyDetail policyData) {

		PolicyDetail policyMaster = policyRepo.findByPolicyID(policyID);
	           // .orElseThrow(() -> new ResourceNotFoundException("PolicyMaster", "id", policyID));

		policyMaster.setPolicyName(policyData.getPolicyName());
		policyMaster.setDescription(policyData.getDescription());
		policyMaster.setType(policyData.getType());
		policyMaster.setCoverAmount(policyData.getCoverAmount());
		policyMaster.setPremium(policyData.getPremium());
		policyMaster.setEntryAge(policyData.getEntryAge());
		policyMaster.setTerm(policyData.getTerm());

		PolicyDetail updatedPolicy = policyRepo.save(policyMaster);
	    return updatedPolicy;
	}

	//GET http://localhost:8004/api/user/manu
	// Get a Single User details for welcome name inclusion
	@GetMapping("/user/{id}")
	public UserDetail getUserDetail(@PathVariable(value = "id") String userID) {
		  return userRepo.findByUserId(userID);
 		 // .orElseThrow(() -> new ResourceNotFoundException("PolicyMaster", "id", policyID));
	}
}
