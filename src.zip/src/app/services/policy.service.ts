import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { User } from '../models/index';

@Injectable()
export class PolicyService {
    constructor(private http: HttpClient) { }

	host = "http://localhost:8090";
	
    // policy master
    getAll() {
        return this.http.get<any[]>(this.host+'/policy/all');
    }

    getById(id: number) {
        return this.http.get(this.host+'/policy/get/' + id);
    }

    update(policy: any) {
        return this.http.put(this.host+'/policy/update/' + policy.policyId, policy);
    }

    // user policies
    getUserAllPolicies(userId: number) {
        return this.http.get<any[]>(this.host+'/user/policies?userid='+ userId);
    }
}