/**
 * 
 */
package com.policymgmtsystem.pmsdemo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * @author student
 *
 */
@Entity
@Table(name = "userpolicysubscriptions")
public class Subscription {
	@Id
	@Column(name = "subscriptionid")
	private String subscriptionId = null;
	@Column(name = "policyid")
	private String policyId = null;
	@Column(name = "effectivedate")
	private String effectiveDate = null;
	@Column(name = "maturitydate")
	private String maturityDate = null;
	@Column(name = "premiumamount")
	private String premiumAmount = null;
	@Column(name = "nomineename")
	private String nomineeName = null;
	@Column(name = "nomineerelation")
	private String nomineeRelation = null;
	@Transient
	private PolicyDetail policyDetail = null;
	@Transient
	private UserDetail userDetail = null;

	/**
	 * @return the subscriptionId
	 */
	public String getSubscriptionId() {
		return subscriptionId;
	}

	/**
	 * @param subscriptionId
	 *            the subscriptionId to set
	 */
	public void setSubscriptionId(String subscriptionId) {
		this.subscriptionId = subscriptionId;
	}

	/**
	 * @return the policyId
	 */
	public String getPolicyId() {
		return policyId;
	}

	/**
	 * @param policyId
	 *            the policyId to set
	 */
	public void setPolicyId(String policyId) {
		this.policyId = policyId;
	}

	/**
	 * @return the effectiveDate
	 */
	public String getEffectiveDate() {
		return effectiveDate;
	}

	/**
	 * @param effectiveDate
	 *            the effectiveDate to set
	 */
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	/**
	 * @return the maturityDate
	 */
	public String getMaturityDate() {
		return maturityDate;
	}

	/**
	 * @param maturityDate
	 *            the maturityDate to set
	 */
	public void setMaturityDate(String maturityDate) {
		this.maturityDate = maturityDate;
	}

	/**
	 * @return the premiumAmount
	 */
	public String getPremiumAmount() {
		return premiumAmount;
	}

	/**
	 * @param premiumAmount
	 *            the premiumAmount to set
	 */
	public void setPremiumAmount(String premiumAmount) {
		this.premiumAmount = premiumAmount;
	}

	/**
	 * @return the nomineeName
	 */
	public String getNomineeName() {
		return nomineeName;
	}

	/**
	 * @param nomineeName
	 *            the nomineeName to set
	 */
	public void setNomineeName(String nomineeName) {
		this.nomineeName = nomineeName;
	}

	/**
	 * @return the nomineeRelation
	 */
	public String getNomineeRelation() {
		return nomineeRelation;
	}

	/**
	 * @param nomineeRelation
	 *            the nomineeRelation to set
	 */
	public void setNomineeRelation(String nomineeRelation) {
		this.nomineeRelation = nomineeRelation;
	}

	/**
	 * @return the policyDetail
	 */
	@OneToOne(mappedBy = "subscription")
	public PolicyDetail getPolicyDetail() {
		return policyDetail;
	}

	/**
	 * @param policyDetail
	 *            the policyDetail to set
	 */
	public void setPolicyDetail(PolicyDetail policyDetail) {
		this.policyDetail = policyDetail;
	}

	/**
	 * @return the userDetail
	 */
	@ManyToOne
	@JoinColumn(name = "userid")
	public UserDetail getUserDetail() {
		return userDetail;
	}

	/**
	 * @param userDetail
	 *            the userDetail to set
	 */
	public void setUserDetail(UserDetail userDetail) {
		this.userDetail = userDetail;
	}

	/**
	 * 
	 */
	public Subscription() {
		super();
	}

	/**
	 * @param subscriptionId
	 * @param policyId
	 * @param effectiveDate
	 * @param maturityDate
	 * @param premiumAmount
	 * @param nomineeName
	 * @param nomineeRelation
	 * @param policyDetail
	 * @param userDetail
	 */
	public Subscription(String subscriptionId, String policyId, String effectiveDate, String maturityDate,
			String premiumAmount, String nomineeName, String nomineeRelation, PolicyDetail policyDetail,
			UserDetail userDetail) {
		super();
		this.subscriptionId = subscriptionId;
		this.policyId = policyId;
		this.effectiveDate = effectiveDate;
		this.maturityDate = maturityDate;
		this.premiumAmount = premiumAmount;
		this.nomineeName = nomineeName;
		this.nomineeRelation = nomineeRelation;
		this.policyDetail = policyDetail;
		this.userDetail = userDetail;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((effectiveDate == null) ? 0 : effectiveDate.hashCode());
		result = prime * result + ((maturityDate == null) ? 0 : maturityDate.hashCode());
		result = prime * result + ((nomineeName == null) ? 0 : nomineeName.hashCode());
		result = prime * result + ((nomineeRelation == null) ? 0 : nomineeRelation.hashCode());
		result = prime * result + ((policyDetail == null) ? 0 : policyDetail.hashCode());
		result = prime * result + ((policyId == null) ? 0 : policyId.hashCode());
		result = prime * result + ((premiumAmount == null) ? 0 : premiumAmount.hashCode());
		result = prime * result + ((subscriptionId == null) ? 0 : subscriptionId.hashCode());
		result = prime * result + ((userDetail == null) ? 0 : userDetail.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof Subscription))
			return false;
		Subscription other = (Subscription) obj;
		if (effectiveDate == null) {
			if (other.effectiveDate != null)
				return false;
		} else if (!effectiveDate.equals(other.effectiveDate))
			return false;
		if (maturityDate == null) {
			if (other.maturityDate != null)
				return false;
		} else if (!maturityDate.equals(other.maturityDate))
			return false;
		if (nomineeName == null) {
			if (other.nomineeName != null)
				return false;
		} else if (!nomineeName.equals(other.nomineeName))
			return false;
		if (nomineeRelation == null) {
			if (other.nomineeRelation != null)
				return false;
		} else if (!nomineeRelation.equals(other.nomineeRelation))
			return false;
		if (policyDetail == null) {
			if (other.policyDetail != null)
				return false;
		} else if (!policyDetail.equals(other.policyDetail))
			return false;
		if (policyId == null) {
			if (other.policyId != null)
				return false;
		} else if (!policyId.equals(other.policyId))
			return false;
		if (premiumAmount == null) {
			if (other.premiumAmount != null)
				return false;
		} else if (!premiumAmount.equals(other.premiumAmount))
			return false;
		if (subscriptionId == null) {
			if (other.subscriptionId != null)
				return false;
		} else if (!subscriptionId.equals(other.subscriptionId))
			return false;
		if (userDetail == null) {
			if (other.userDetail != null)
				return false;
		} else if (!userDetail.equals(other.userDetail))
			return false;
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Subscription [subscriptionId=");
		builder.append(subscriptionId);
		builder.append(", policyId=");
		builder.append(policyId);
		builder.append(", effectiveDate=");
		builder.append(effectiveDate);
		builder.append(", maturityDate=");
		builder.append(maturityDate);
		builder.append(", premiumAmount=");
		builder.append(premiumAmount);
		builder.append(", nomineeName=");
		builder.append(nomineeName);
		builder.append(", nomineeRelation=");
		builder.append(nomineeRelation);
		builder.append(", policyDetail=");
		builder.append(policyDetail);
		builder.append(", userDetail=");
		builder.append(userDetail);
		builder.append("]");
		return builder.toString();
	}

}
