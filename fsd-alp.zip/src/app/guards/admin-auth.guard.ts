import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';
import { AuthenticationService } from '../services/authentication.service';

@Injectable()
export class AdminAuthGuard implements CanActivate {

  constructor(private authService: AuthenticationService) {}; 

  canActivate() {
    if (this.authService.isAdminLoggedIn()) { 
      return true;
    } else {
      window.alert("You don't have permission to view this page"); 
      return false;
    }
  }
}