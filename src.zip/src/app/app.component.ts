import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthenticationService } from './services/authentication.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Policy Manager';

  constructor(private route: ActivatedRoute,
              private router: Router,
              private authService: AuthenticationService) {}

  logout() {
    this.authService.logout();
    this.router.navigate(["/"]);
  }

}
