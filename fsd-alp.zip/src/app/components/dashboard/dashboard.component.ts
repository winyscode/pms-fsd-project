import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../../services/authentication.service';
import { PolicyService } from '../../services/policy.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  //TODO: remove default values
  policyList = [
    {id: 1, name: "Health Insurance Policy 1", details: "Policy 1 details"},
    {id: 2, name: "Health Insurance Policy 2", details: "Policy 2 details"},
    {id: 3, name: "Health Insurance Policy 3", details: "Policy 3 details"},
    {id: 4, name: "Health Insurance Policy 4", details: "Policy 4 details"},
    {id: 5, name: "Health Insurance Policy 5", details: "Policy 5 details"},
    {id: 6, name: "Health Insurance Policy 6", details: "Policy 6 details"}
  ];

  userPolicyList = [
    {id: 1, name: "Health Insurance Policy 1", amount: 5000, endDate: "2020-04-19"},
    {id: 2, name: "Health Insurance Policy 2", amount: 10500, endDate: "2017-03-20" },
    {id: 3, name: "Health Insurance Policy 3", amount: 7900, endDate: "2018-04-29" }
  ];

  user: {} = {};

  constructor(private authService: AuthenticationService,
              private policyService: PolicyService) { }

  isValidDate(mDate: string): boolean {
    let q:any = new Date(), m = q.getMonth(), d = q.getDate(), y = q.getFullYear(), date = new Date(y,m,d);
    let mydate: any = new Date(mDate);
    return (date < mydate);
  }

  ngOnInit() {

      this.user = this.authService.getUserDetails();

      this.policyService.getAll().subscribe(
        data => {
           //TODO: uncomment>> this.policyList = data;
        },
        error => {
            alert("Policy API failed");
            console.log(error.message);
      });
    

    
      this.policyService.getUserAllPolicies(this.user['id']).subscribe(
        data => {
           //TODO: uncomment?>> this.userPolicyList = data;
        },
        error => {
            alert("User Policy API failed");
            console.log(error.message);
      });
    
  }

}
