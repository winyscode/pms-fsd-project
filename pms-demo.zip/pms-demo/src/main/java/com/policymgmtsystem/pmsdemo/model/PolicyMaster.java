/**
 * 
 */
package com.policymgmtsystem.pmsdemo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * @author student
 *
 */
@Entity
@Table(name = "policymaster")
public class PolicyMaster {
	@Id
	@Column(name ="policyid")
	private String policyID = null;
	@Column(name ="policyname")
	private String policyName = null;
	@Column(name ="type")
	private String type = null;
	@Column(name ="description")
	private String description = null;
	@Column(name ="term")
	private String term = null;
	@Column(name ="premium")
	private String premium = null;
	@Column(name ="coveramount")
	private String coverAmount = null;
	@Column(name ="entryage")
	private String entryAge = null;
	/**
	 * @return the policyID
	 */
	public String getPolicyID() {
		return policyID;
	}
	/**
	 * @param policyID the policyID to set
	 */
	public void setPolicyID(String policyID) {
		this.policyID = policyID;
	}
	/**
	 * @return the policyName
	 */
	public String getPolicyName() {
		return policyName;
	}
	/**
	 * @param policyName the policyName to set
	 */
	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the term
	 */
	public String getTerm() {
		return term;
	}
	/**
	 * @param term the term to set
	 */
	public void setTerm(String term) {
		this.term = term;
	}
	/**
	 * @return the premium
	 */
	public String getPremium() {
		return premium;
	}
	/**
	 * @param premium the premium to set
	 */
	public void setPremium(String premium) {
		this.premium = premium;
	}
	/**
	 * @return the coverAmount
	 */
	public String getCoverAmount() {
		return coverAmount;
	}
	/**
	 * @param coverAmount the coverAmount to set
	 */
	public void setCoverAmount(String coverAmount) {
		this.coverAmount = coverAmount;
	}
	/**
	 * @return the entryAge
	 */
	public String getEntryAge() {
		return entryAge;
	}
	/**
	 * @param entryAge the entryAge to set
	 */
	public void setEntryAge(String entryAge) {
		this.entryAge = entryAge;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((coverAmount == null) ? 0 : coverAmount.hashCode());
		result = prime * result + ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((entryAge == null) ? 0 : entryAge.hashCode());
		result = prime * result + ((policyID == null) ? 0 : policyID.hashCode());
		result = prime * result + ((policyName == null) ? 0 : policyName.hashCode());
		result = prime * result + ((premium == null) ? 0 : premium.hashCode());
		result = prime * result + ((term == null) ? 0 : term.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof PolicyMaster))
			return false;
		PolicyMaster other = (PolicyMaster) obj;
		if (coverAmount == null) {
			if (other.coverAmount != null)
				return false;
		} else if (!coverAmount.equals(other.coverAmount))
			return false;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (entryAge == null) {
			if (other.entryAge != null)
				return false;
		} else if (!entryAge.equals(other.entryAge))
			return false;
		if (policyID == null) {
			if (other.policyID != null)
				return false;
		} else if (!policyID.equals(other.policyID))
			return false;
		if (policyName == null) {
			if (other.policyName != null)
				return false;
		} else if (!policyName.equals(other.policyName))
			return false;
		if (premium == null) {
			if (other.premium != null)
				return false;
		} else if (!premium.equals(other.premium))
			return false;
		if (term == null) {
			if (other.term != null)
				return false;
		} else if (!term.equals(other.term))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		return true;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("PolicyMaster [policyID=");
		builder.append(policyID);
		builder.append(", policyName=");
		builder.append(policyName);
		builder.append(", type=");
		builder.append(type);
		builder.append(", description=");
		builder.append(description);
		builder.append(", term=");
		builder.append(term);
		builder.append(", premium=");
		builder.append(premium);
		builder.append(", coverAmount=");
		builder.append(coverAmount);
		builder.append(", entryAge=");
		builder.append(entryAge);
		builder.append("]");
		return builder.toString();
	}
	
}
