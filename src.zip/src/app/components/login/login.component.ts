import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthenticationService } from '../../services/authentication.service';

@Component({
  selector: 'app-login-component',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginDetails: any = {};
  returnUrl: string = "dashboard";

  constructor(private route: ActivatedRoute,
              private router: Router,
              private authService: AuthenticationService) { }

  // call to login service when user submits form         
  login() {
    this.authService.login(this.loginDetails.username, this.loginDetails.password).subscribe(
        data => {
            this.router.navigate([this.returnUrl]);
        },
        error => {
            alert("Login failed");
            console.log(error.message);
      });
  }

  ngOnInit() { 

    if(this.authService.isLoggedIn()) {
       this.router.navigate(["/dashboard"]);
    }
  }

}
