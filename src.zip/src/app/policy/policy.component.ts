import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, Params} from '@angular/router';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl, FormsModule, ReactiveFormsModule} from '@angular/forms';
import 'rxjs/add/operator/filter';
import 'rxjs/Rx';
import { PolicyService } from '../services/policy.service';

@Component({
  selector: 'app-policy',
  templateUrl: './policy.component.html',
  styleUrls: ['./policy.component.css']
})
export class PolicyComponent implements OnInit {
	
	formData: FormGroup;
	
  constructor(private router: Router, private route: ActivatedRoute,
			private policyService: PolicyService,
			private fb: FormBuilder) {  
			
		this.formData = this.fb.group({
			policyId: [null, Validators.required], 
			name: [null, Validators.required], 
			description: [null, Validators.required]
		});
		
	}
			
  ngOnInit() {	
  
	this.route.params
		.switchMap((params: Params) => this.policyService.getById(+params['id']))
		.subscribe(policy => {
			this.formData.setValue(policy);
		});
  }
  
  onSubmit(data){
	 if(this.formData.valid){
		 this.policyService.update(data).subscribe(data => {
			 this.router.navigate(["/dashboard"]);
		 });
		 
	 }
  }

}
