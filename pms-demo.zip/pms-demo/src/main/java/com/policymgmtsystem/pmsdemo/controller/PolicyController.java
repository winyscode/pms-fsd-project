package com.policymgmtsystem.pmsdemo.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.policymgmtsystem.pmsdemo.exception.ResourceNotFoundException;
import com.policymgmtsystem.pmsdemo.model.PolicyMaster;
import com.policymgmtsystem.pmsdemo.repository.PolicyRepository;

@RestController
@RequestMapping("/api")
public class PolicyController {

	@Autowired
	PolicyRepository policyRepo;

	// Get all policies for Admin
	@GetMapping("/policies")
	public List<PolicyMaster> getAllPolicies() {
		return policyRepo.findAll();

	}
	
	// Get a Single Policy for Admin to view and edit
	@GetMapping("/policies/{id}")
	public PolicyMaster getPolicyById(@PathVariable(value = "id") String policyID) {
	    return policyRepo.findByPolicyID(policyID);
	    		 // .orElseThrow(() -> new ResourceNotFoundException("PolicyMaster", "id", policyID));
	}
	
	// Update a Policy
	@PutMapping("/policies/{id}")
	public PolicyMaster updatePolicy(@PathVariable(value = "id") Long policyID,
	                                        @Valid @RequestBody PolicyMaster policyData) {

		PolicyMaster policyMaster = policyRepo.findById(policyID)
	            .orElseThrow(() -> new ResourceNotFoundException("PolicyMaster", "id", policyID));

		policyMaster.setPolicyName(policyData.getPolicyName());
		policyMaster.setDescription(policyData.getDescription());
		policyMaster.setType(policyData.getType());
		policyMaster.setCoverAmount(policyData.getCoverAmount());
		policyMaster.setPremium(policyData.getPremium());
		policyMaster.setEntryAge(policyData.getEntryAge());
		policyMaster.setTerm(policyData.getTerm());

		PolicyMaster updatedPolicy = policyRepo.save(policyMaster);
	    return updatedPolicy;
	}

}
