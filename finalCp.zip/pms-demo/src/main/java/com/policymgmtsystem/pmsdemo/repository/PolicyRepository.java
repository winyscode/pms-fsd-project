package com.policymgmtsystem.pmsdemo.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.policymgmtsystem.pmsdemo.model.PolicyDetail;

@Repository
public interface PolicyRepository extends JpaRepository<PolicyDetail, Long>{

	PolicyDetail findByPolicyID(String policyID);

}
