package com.policymgmtsystem.pmsdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PmsDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(PmsDemoApplication.class, args);
	}
}
