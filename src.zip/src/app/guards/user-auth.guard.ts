import { Injectable } from '@angular/core';
import { CanActivate } from "@angular/router";
import { AuthenticationService } from '../services/authentication.service';

@Injectable()
export class UserAuthGuard implements CanActivate {

  constructor(private authService: AuthenticationService) {}; 

  canActivate() {
    if (this.authService.isLoggedIn()) { 
      return true;
    } else {
      window.alert("You don't have permission to view this page"); 
      return false;
    }
  }
}