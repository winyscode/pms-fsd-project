import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { User } from '../models/index';

@Injectable()
export class PolicyService {
    constructor(private http: HttpClient) { }

    // policy master
    getAll() {
        return this.http.get<User[]>('/api/policies');
    }

    getById(id: number) {
        return this.http.get('/api/policies/' + id);
    }

    create(policy: {}) {
        return this.http.post('/api/policies', policy);
    }

    update(policy: {}) {
        return this.http.put('/api/policies/' + policy.id, policy);
    }

    delete(id: number) {
        return this.http.delete('/api/policies/' + id);
    }

    // user policies
    getUserAllPolicies(userId: number) {
        return this.http.get<User[]>('/api/user-policies/'+ userId);
    }
}